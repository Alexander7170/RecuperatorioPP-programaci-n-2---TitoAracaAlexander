/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package recuperatoriopp.titoaraca.alexander.Entidades;

/**
 *
 * @author Alexander
 */
public class Fabricante {
    private String nombre;
    private String ciudad;
    private int antiguedad;

    public Fabricante(String nombre, String ciudad, int antiguedad) {
        this.nombre = nombre;
        this.ciudad = ciudad;
        this.antiguedad = antiguedad;
    }
    
    public static boolean sonIguales(Fabricante f1, Fabricante f2){
        
        return f1.getInfoFabricante().equals(f2.getInfoFabricante());
    }
    
    private String getInfoFabricante(){
        StringBuilder info = new StringBuilder();
        info.append("\n nombre: ").append(this.nombre);
        info.append("\n ciudad fabricante: ").append(this.ciudad);
        info.append("\n Antiguedad: ").append(this.antiguedad);
        return info.toString();
    }
    
    @Override
    public String toString(){
        return this.getInfoFabricante();
    }
}
