/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package recuperatoriopp.titoaraca.alexander.Entidades;

/**
 *
 * @author Alexander
 */
public class Pizza extends Producto implements  IVendible{
    private TipoPizza sabor;
    private TamanoPizza tamano;

    public Pizza(String nombre, double precio, Fabricante fabricante, TipoPizza sabor, TamanoPizza tamano) {
        super(nombre, precio, fabricante);
        this.sabor = sabor;
        this.tamano = tamano;
    }
    @Override
    public double getPrecioTotal(){
        double precioTotal = super.precio;
        if(this.tamano == TamanoPizza.CHICA){
            precioTotal += precioTotal * 0.05;
        }
        else if(this.tamano == TamanoPizza.MEDIANA){
            precioTotal += precioTotal * 0.1;
        }
        else{precioTotal += precioTotal * 0.2;}
        
        return precioTotal;
    }
    @Override
    public String toString(){
        StringBuilder info = new StringBuilder(super.toString());
        info.append("\n sabor: ").append(this.sabor);
        info.append("\n tamaño: ").append(this.tamano);
        return info.toString();
    }
    
    @Override
    public boolean equals(Object obj){
        if(this == obj) return true;
        if(!(obj instanceof Pizza)) return false;
        Pizza pizza = (Pizza) obj;
        return super.equals(pizza) && this.sabor == pizza.sabor && this.tamano == pizza.tamano;
    }
    
}
