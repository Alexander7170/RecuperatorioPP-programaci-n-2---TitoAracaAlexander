/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package recuperatoriopp.titoaraca.alexander.Entidades;

import java.util.Random;

/**
 *
 * @author Alexander
 */
public abstract class Producto {
    protected Fabricante fabricante;
    protected String nombre;
    protected double precio;
    protected int calorias;
    protected int tiempoPreparacion;
    protected static Random generadorAleatorio;

    public Producto(String nombre, double precio, Fabricante fabricante) {
        this.fabricante = fabricante;
        this.nombre = nombre;
        this.precio = precio;
    }
    
    public Producto(String nombre, double precio, String nombreFabricante, String ciudadFabricante, int antiguedadFabricante){
        this(nombre, precio, new Fabricante(nombreFabricante, ciudadFabricante, antiguedadFabricante));
    }
    static{
        Producto.generadorAleatorio = new Random();
    }
    
    public int getCalorias(){
        if(this.calorias == 0){
            this.calorias = Producto.generadorAleatorio.nextInt(200, 801);
        }
        return this.calorias;
    }
    
    public int getTiempoPreparacion(){
        if(this.tiempoPreparacion == 0){
            this.tiempoPreparacion = Producto.generadorAleatorio.nextInt(5, 21);
        }
        return this.tiempoPreparacion;
    }
    
    private static String mostrar(Producto p1){
        StringBuilder info = new StringBuilder();
        info.append("nombre producto: ").append(p1.nombre);
        info.append("\n Precio Producto: ").append(p1.precio);
        info.append("\n Calorias: ").append(p1.getCalorias());
        info.append("\n tiempo preparacion: ").append(p1.getTiempoPreparacion());
        info.append("\n Fabricante: ").append(p1.fabricante.toString());
        return info.toString();
    }
    @Override
    public String toString(){
        return Producto.mostrar(this);
    }
    
    private static boolean sonIguales(Producto p1, Producto p2){
        return p1.toString().equals(p2.toString());
    }
    @Override
    public boolean equals(Object obj){
        if(this == obj)return true;
        if(!(obj instanceof Producto))return false;
        Producto producto = (Producto) obj;
        return Producto.sonIguales(this, producto);
    }
}
