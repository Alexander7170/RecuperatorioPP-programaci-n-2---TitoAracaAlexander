/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package recuperatoriopp.titoaraca.alexander.Entidades;

/**
 *
 * @author Alexander
 */
public class Postre extends Producto implements IVendible{
    private TipoPostre tipoPostre;

    public Postre(String nombre, double precio, Fabricante fabricante, TipoPostre tipoPostre) {
        super(nombre, precio, fabricante);
        this.tipoPostre = tipoPostre;
    }
    
    @Override
    public double getPrecioTotal(){
        double precioTotal = super.precio;
        if(this.tipoPostre == TipoPostre.HELADO){
            precioTotal += precioTotal * 0.15;
        }
        else if(this.tipoPostre == TipoPostre.FLAN){
            precioTotal += precioTotal * 0.1;
        }
        else{precioTotal += precioTotal * 0.2;}
        
        return precioTotal;
    }
    @Override
    public String toString(){
        StringBuilder info = new StringBuilder(super.toString());
        info.append("\n tipo postre: ").append(this.tipoPostre);
        return info.toString();
    }
    
    @Override
    public boolean equals(Object obj){
        if(this == obj) return true;
        if(!(obj instanceof Postre)) return false;
        Postre postre = (Postre) obj;
        return super.equals(postre) && this.tipoPostre == postre.tipoPostre;
    }
    
}
