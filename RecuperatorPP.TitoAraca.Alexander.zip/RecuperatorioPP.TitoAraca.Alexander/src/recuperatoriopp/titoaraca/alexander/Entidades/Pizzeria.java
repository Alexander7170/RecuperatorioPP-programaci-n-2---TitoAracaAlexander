/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package recuperatoriopp.titoaraca.alexander.Entidades;

import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author Alexander
 */
public class Pizzeria implements Iterable<Producto>{
    
    private String nombre;
    private int capacidad;
    private ArrayList<Producto> productos;

    public Pizzeria(String nombre) {
        this.nombre = nombre;
        this.productos = new ArrayList<>();
        this.capacidad = 3;
    }
    
    public Pizzeria(String nombre, int capacidad){
        this(nombre);
        this.capacidad = capacidad;
    }
    private boolean sonIguales(Producto p1){
        boolean iguales = false;
        for(Producto item : this.productos){
            if(item instanceof Pizza){
                Pizza pizza = (Pizza) item;
                iguales = pizza.equals(p1);
            }
            else{
                Postre postre = (Postre)item;
                iguales = postre.equals(p1);
            }
            if (iguales) {
                break;
            }
        }
        return iguales;
    }
    
    public void agregar(Producto p1){
        if(this.sonIguales(p1) == false && capacidad > this.productos.size()){
            productos.add(p1);
        }
    }
    private double getPrecioProductos(TipoProducto t){
        double precioTotal = 0;
        for(Producto item: this.productos){
            if( item instanceof  Pizza && (t == TipoProducto.PIZZAS || t == TipoProducto.TODOS)){
                Pizza pizza = (Pizza)item;
                precioTotal+= pizza.getPrecioTotal();
            }
            if( item instanceof  Postre && (t == TipoProducto.POSTRES|| t == TipoProducto.TODOS)){
                Postre postre = (Postre)item;
                precioTotal+= postre.getPrecioTotal();
            }
        }
        return precioTotal;
    }
    
    private double getPrecioDePizzas(){
        return this.getPrecioProductos(TipoProducto.PIZZAS);
    }
    
    private double getPrecioDePostres(){
        return this.getPrecioProductos(TipoProducto.POSTRES);
    }
    private double getPrecioTotal(){
        return this.getPrecioProductos(TipoProducto.TODOS);
    }
    @Override
    public Iterator<Producto> iterator() {
    return productos.iterator();
    }
    @Override
    public String toString(){
        StringBuilder info = new StringBuilder();
        info.append("Nombre pizzeria: ").append(this.nombre);
        info.append("\n cantidad de productos: ").append(this.productos.size());
        info.append("\n Precio totales de Pizzas: ").append(this.getPrecioDePizzas());
        info.append("\n Precio totales de postres: ").append(this.getPrecioDePostres());
        info.append("\n precio total de todos los productos: ").append(this.getPrecioTotal());
        for (Producto p : this) {
        info.append(p.toString()).append("\n");
        }
        return info.toString();
    }
}
