/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package recuperatoriopp.titoaraca.alexander.Entidades;

import javax.print.attribute.standard.MediaName;

/**
 *
 * @author Alexander
 */
public enum TamanoPizza {
    CHICA,
    MEDIANA,
    GRANDE
}
